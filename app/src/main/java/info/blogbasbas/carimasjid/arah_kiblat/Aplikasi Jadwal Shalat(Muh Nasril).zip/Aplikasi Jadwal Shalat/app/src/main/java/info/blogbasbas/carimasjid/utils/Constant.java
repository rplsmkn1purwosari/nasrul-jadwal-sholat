package info.blogbasbas.carimasjid.utils;


public class Constant {
    public static final String BASE_URL ="https://script.google.com/" ;
    public static final String URL_UAS ="macros/s/AKfycbyvnmKsJj8O4tijb0IPOlPCMFUM7GQxJMH8PtTxtYq76pWWx52J/exec?action=readAll";

}
