package info.blogbasbas.carimasjid.utils;

public interface LocationImpl {
    void onDestroyLocationUtils();
    void onStartLocationUtils();
}
