package info.blogbasbas.carimasjid.activity.splascreen;

public interface SplashscreenView {
    void onPrepare ();
    void onProgress(int progress);

    void onSuccess();
}
