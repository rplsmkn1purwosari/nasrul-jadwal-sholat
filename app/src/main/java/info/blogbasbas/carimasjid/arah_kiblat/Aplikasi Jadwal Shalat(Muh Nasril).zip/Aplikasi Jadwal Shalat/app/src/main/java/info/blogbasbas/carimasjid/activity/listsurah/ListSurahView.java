package info.blogbasbas.carimasjid.activity.listsurah;

import info.blogbasbas.carimasjid.base.BaseView;
import info.blogbasbas.carimasjid.modelquran.Ayat;
import info.blogbasbas.carimasjid.modelquran.Surah;


interface ListSurahView  extends BaseView<Surah> {
}
