package info.blogbasbas.carimasjid.activity.listayat;

import info.blogbasbas.carimasjid.base.BaseView;
import info.blogbasbas.carimasjid.modelquran.Ayat;


public interface ListAyatView extends BaseView<Ayat> {
}
