package info.blogbasbas.carimasjid.activity.notes;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import info.blogbasbas.carimasjid.R;

public class tambah_notes extends AppCompatActivity {

    String var_judul, var_deskripsi, var_tanggal;
    EditText judul, deskripsi, tanggal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_notes);

        judul = (EditText)findViewById(R.id.inputJudul);
        deskripsi = (EditText)findViewById(R.id.inputDeskripsi);
        tanggal = (EditText) findViewById(R.id.inputTanggal);

        Button simpan = (Button) findViewById(R.id.btnSimpan);
        simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                var_judul = judul.getText().toString();
                var_deskripsi = deskripsi.getText().toString();
                var_tanggal = tanggal.getText().toString();

                Intent i = null;

                i = new Intent(tambah_notes.this, NotesActivity.class);
                Bundle b =new Bundle();
                b.putString("parse_judul", var_judul);
                b.putString("parse_deskripsi", var_deskripsi);
                b.putString("parse_tanggal", var_tanggal);

                i.putExtras(b);
                startActivity(i);
            }
        });
    }
}
