package info.blogbasbas.carimasjid.activity.ceramah.adapter;

/**
 * Created by User on 06/05/2018.
 */

public class AdapterUstadADi {
}
