package info.blogbasbas.carimasjid.activity.listayat;

import info.blogbasbas.carimasjid.base.BaseView;
import info.blogbasbas.carimasjid.modelquran.Ayat;

/**
 * Created by User on 01/05/2018.
 */

public interface ListAyatView extends BaseView<Ayat> {
}
