package info.blogbasbas.carimasjid.utils;

/**
 * Created by ocittwo on 2/26/17.
 *
 * @Author Ahmad Rosid
 * @Email ocittwo@gmail.com
 * @Github https://github.com/ar-android
 * @Web http://ahmadrosid.com
 */
public interface LocationImpl {
    void onDestroyLocationUtils();
    void onStartLocationUtils();
}
