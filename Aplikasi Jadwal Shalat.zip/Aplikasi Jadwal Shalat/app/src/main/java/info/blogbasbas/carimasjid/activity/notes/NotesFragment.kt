package info.blogbasbas.carimasjid.activity.notes

class NotesFragment {
}