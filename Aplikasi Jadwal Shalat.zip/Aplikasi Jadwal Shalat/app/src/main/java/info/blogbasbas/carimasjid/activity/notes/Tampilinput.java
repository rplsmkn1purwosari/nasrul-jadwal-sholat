package info.blogbasbas.carimasjid.activity.notes;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import info.blogbasbas.carimasjid.R;

public class Tampilinput extends Activity {



    TextView judul,deskripsi,tanggal;
    String get_labelJudul,get_labelDeskripsi,get_Tanggal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        judul = (TextView)findViewById(R.id.inputJudul);
        deskripsi = (TextView) findViewById(R.id.inputDeskripsi);
        tanggal = (TextView) findViewById(R.id.inputTanggal);

        Bundle b = getIntent().getExtras();

        get_labelJudul = b.getString("parse_judul");
        get_labelDeskripsi = b.getString("parse_deskripsi");
        get_Tanggal = b.getString("parse_tanggal");

        judul.setText("Judul:" +get_labelJudul);
        deskripsi.setText("Deskripsi:" +get_labelDeskripsi);
        tanggal.setText("Tanggal" +get_Tanggal);

        Button Hapus = (Button)findViewById(R.id.btnHapus);
        Hapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                judul.setText("");
                deskripsi.setText("");
                tanggal.setText("");
            }
        });
    }
}

