package info.blogbasbas.carimasjid.base;

import java.util.ArrayList;


public interface BaseView<M> {
    public void onLoad(ArrayList<M> data);
}
