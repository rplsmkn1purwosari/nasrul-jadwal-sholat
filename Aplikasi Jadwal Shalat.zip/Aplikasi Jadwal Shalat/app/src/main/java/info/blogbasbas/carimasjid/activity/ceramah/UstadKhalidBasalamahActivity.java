package info.blogbasbas.carimasjid.activity.ceramah;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import info.blogbasbas.carimasjid.R;

public class UstadKhalidBasalamahActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ustad_khalid_basalamah);
    }
}
