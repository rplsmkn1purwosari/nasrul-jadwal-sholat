package info.blogbasbas.carimasjid.activity.splascreen;

/**
 * Created by User on 01/05/2018.
 */

public interface SplashscreenView {
    void onPrepare ();
    void onProgress(int progress);

    void onSuccess();
}
